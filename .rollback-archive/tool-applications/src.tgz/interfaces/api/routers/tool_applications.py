"""ETHAN API gateway for manifest-backed Tool application management."""

from __future__ import annotations

import logging
from typing import Literal

from core.auth import Permission
from core.deployment.tool_manager import (
    ToolConfigurationError,
    ToolConfirmationRequired,
    ToolDependencyError,
    ToolDockerError,
    ToolManager,
    ToolNotFoundError,
    ToolOperationNotAllowed,
    ToolPortConflict,
    ToolTimeoutError,
)
from core.deployment.tool_registry import ToolApplicationRegistry
from fastapi import APIRouter, Body, Depends, HTTPException, Query, Request
from interfaces.api.auth import current_user_id, require_permission
from pydantic import BaseModel

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/v1/tool-applications", tags=["tool-applications"])
_registry: ToolApplicationRegistry | None = None
_manager: ToolManager | None = None


def set_tool_application_registry(registry: ToolApplicationRegistry | None) -> None:
    global _registry
    _registry = registry


def set_tool_manager(manager: ToolManager | None) -> None:
    global _manager
    _manager = manager


def get_tool_application_registry() -> ToolApplicationRegistry:
    if _registry is None:
        raise HTTPException(status_code=503, detail="Tool application registry not initialized")
    return _registry


def get_tool_manager() -> ToolManager:
    if _manager is None:
        raise HTTPException(status_code=503, detail="Tool Manager not initialized")
    return _manager


def _not_found(tool_id: str) -> HTTPException:
    return HTTPException(status_code=404, detail=f"Tool application '{tool_id}' not found")


def _manager_error(exc: Exception) -> HTTPException:
    if isinstance(exc, ToolNotFoundError):
        return HTTPException(status_code=404, detail=str(exc))
    if isinstance(exc, ToolOperationNotAllowed | ToolDependencyError | ToolPortConflict):
        return HTTPException(status_code=409, detail=str(exc))
    if isinstance(exc, ToolConfirmationRequired):
        return HTTPException(status_code=400, detail=str(exc))
    if isinstance(exc, ToolConfigurationError):
        return HTTPException(status_code=422, detail=str(exc))
    if isinstance(exc, ToolTimeoutError):
        return HTTPException(status_code=504, detail=str(exc))
    if isinstance(exc, ToolDockerError):
        return HTTPException(status_code=502, detail=str(exc))
    logger.exception("Unexpected Tool Manager API error", exc_info=exc)
    return HTTPException(status_code=500, detail="Erreur interne du Tool Manager")


class UninstallRequest(BaseModel):
    delete_volumes: bool = False
    confirm_data_deletion: Literal["DELETE_TOOL_DATA"] | None = None


@router.get("", dependencies=[Depends(require_permission(Permission.READ))])
async def list_tool_applications():
    try:
        tools = await get_tool_manager().list_tools()
        return {"items": tools, "count": len(tools)}
    except Exception as exc:
        raise _manager_error(exc) from exc


@router.get("/discovery-errors", dependencies=[Depends(require_permission(Permission.ADMIN))])
async def get_discovery_errors():
    return {"items": get_tool_application_registry().discovery_errors()}


@router.get("/{tool_id}/status", dependencies=[Depends(require_permission(Permission.READ))])
async def get_tool_application_status(tool_id: str):
    try:
        return await get_tool_manager().status(tool_id)
    except Exception as exc:
        raise _manager_error(exc) from exc


@router.get("/{tool_id}/health", dependencies=[Depends(require_permission(Permission.READ))])
async def get_tool_application_health(tool_id: str):
    try:
        return await get_tool_manager().health(tool_id)
    except Exception as exc:
        raise _manager_error(exc) from exc


@router.get("/{tool_id}", dependencies=[Depends(require_permission(Permission.READ))])
async def get_tool_application(tool_id: str):
    try:
        return await get_tool_manager().get_tool(tool_id)
    except Exception as exc:
        raise _manager_error(exc) from exc


@router.get("/{tool_id}/logs", dependencies=[Depends(require_permission(Permission.READ))])
async def get_tool_application_logs(
    tool_id: str,
    request: Request,
    tail: int = Query(default=200, ge=1, le=1000),
):
    try:
        return await get_tool_manager().logs(tool_id, tail=tail, actor=current_user_id(request))
    except Exception as exc:
        raise _manager_error(exc) from exc


async def _run_operation(tool_id: str, operation: str, request: Request):
    try:
        manager = get_tool_manager()
        actor = current_user_id(request)
        return await getattr(manager, operation)(tool_id, actor=actor)
    except Exception as exc:
        raise _manager_error(exc) from exc


@router.post("/{tool_id}/install", dependencies=[Depends(require_permission(Permission.ADMIN))])
async def install_tool_application(tool_id: str, request: Request):
    return await _run_operation(tool_id, "install", request)


@router.post("/{tool_id}/start", dependencies=[Depends(require_permission(Permission.ADMIN))])
async def start_tool_application(tool_id: str, request: Request):
    return await _run_operation(tool_id, "start", request)


@router.post("/{tool_id}/stop", dependencies=[Depends(require_permission(Permission.ADMIN))])
async def stop_tool_application(tool_id: str, request: Request):
    return await _run_operation(tool_id, "stop", request)


@router.post("/{tool_id}/restart", dependencies=[Depends(require_permission(Permission.ADMIN))])
async def restart_tool_application(tool_id: str, request: Request):
    return await _run_operation(tool_id, "restart", request)


@router.post("/{tool_id}/uninstall", dependencies=[Depends(require_permission(Permission.ADMIN))])
async def uninstall_tool_application(
    tool_id: str,
    request: Request,
    payload: UninstallRequest = Body(default=UninstallRequest()),
):
    try:
        return await get_tool_manager().uninstall(
            tool_id,
            actor=current_user_id(request),
            delete_volumes=payload.delete_volumes,
            confirmation=payload.confirm_data_deletion,
        )
    except Exception as exc:
        raise _manager_error(exc) from exc
