"""Read-only registry for applications declared under ``deploy/*``.

This catalog is deliberately separate from ``core.tools.ToolRegistry``: that
registry owns executable agent tools, while this one describes installable or
externally managed applications for the WebUI Tools surface.
"""

from __future__ import annotations

import logging
import os
import re
import threading
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Literal
from urllib.parse import urlparse

import yaml
from pydantic import BaseModel, ConfigDict, Field, ValidationError, field_validator, model_validator

logger = logging.getLogger(__name__)

_ID_PATTERN = re.compile(r"^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$")
_SEMVER_PATTERN = re.compile(r"^\d+\.\d+\.\d+(?:-[0-9A-Za-z.-]+)?(?:\+[0-9A-Za-z.-]+)?$")
_MAX_MANIFEST_BYTES = 64 * 1024


class EnvironmentVariable(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)

    name: str = Field(min_length=1, pattern=r"^[A-Z][A-Z0-9_]*$")
    type: Literal["string", "integer", "boolean", "url", "enum"] = "string"
    required: bool = False
    secret: bool = False
    default: str | int | bool | None = None
    secret_ref: str | None = None
    description: str = ""

    @model_validator(mode="after")
    def validate_secret_reference(self) -> EnvironmentVariable:
        if self.secret and self.default is not None:
            raise ValueError("secret variables cannot declare a default value")
        if self.secret_ref and not self.secret:
            raise ValueError("secret_ref requires secret: true")
        return self


class PortDefinition(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)

    name: str = Field(min_length=1, pattern=r"^[a-zA-Z0-9_-]+$")
    container_port: int = Field(ge=1, le=65535)
    protocol: Literal["tcp", "udp"] = "tcp"
    exposure: Literal["loopback", "internal", "public"] = "loopback"
    host_port: int | Literal["auto"] | None = "auto"


class Management(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)

    mode: Literal["managed", "external"]
    driver: Literal["docker_compose", "none"] = "none"
    compose_file: str | None = None
    project_directory: str | None = None
    project_name: str | None = None
    profiles: list[str] = Field(default_factory=list)

    @field_validator("project_name")
    @classmethod
    def validate_project_name(cls, value: str | None) -> str | None:
        if value is not None and not re.fullmatch(r"[a-z0-9][a-z0-9_-]{0,62}", value):
            raise ValueError("project_name must be a safe lowercase Compose slug")
        return value

    @field_validator("profiles")
    @classmethod
    def validate_profiles(cls, values: list[str]) -> list[str]:
        if any(not re.fullmatch(r"[a-zA-Z0-9][a-zA-Z0-9_.-]{0,62}", value) for value in values):
            raise ValueError("profiles contain an invalid Compose profile name")
        if len(values) != len(set(values)):
            raise ValueError("Compose profiles must be unique")
        return values

    @model_validator(mode="after")
    def validate_driver(self) -> Management:
        if self.mode == "managed" and self.driver == "docker_compose":
            if not self.compose_file or not self.project_directory:
                raise ValueError(
                    "managed docker_compose tools require compose_file and project_directory"
                )
        elif self.mode == "external" and self.driver != "none":
            raise ValueError("external tools must use driver: none")
        return self


class ToolManifest(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)

    apiVersion: Literal["ethan.tools/v1"]
    kind: Literal["ToolApplication"]
    id: str = Field(min_length=1, max_length=63)
    name: str = Field(min_length=1, max_length=120)
    version: str
    description: str = Field(min_length=1, max_length=2000)
    category: str = Field(min_length=1, max_length=64)
    icon: str | None = None
    vendor: str | None = None
    application_type: Literal["web", "service", "worker", "desktop", "cli", "suite"]
    management: Management
    environment: list[EnvironmentVariable] = Field(default_factory=list)
    ports: list[PortDefinition] = Field(default_factory=list)
    web_url: str | None = None
    health_endpoint: str | None = None
    dependencies: list[str] = Field(default_factory=list)
    capabilities: list[str] = Field(default_factory=list)
    integration: dict[str, Any] | None = None
    permissions: list[str] = Field(default_factory=list)
    operations: list[
        Literal[
            "install",
            "start",
            "stop",
            "restart",
            "status",
            "logs",
            "open",
            "uninstall",
        ]
    ] = Field(default_factory=lambda: ["status"])

    @field_validator("id")
    @classmethod
    def validate_id(cls, value: str) -> str:
        if not _ID_PATTERN.fullmatch(value):
            raise ValueError("id must be a lowercase DNS-style slug")
        return value

    @field_validator("version")
    @classmethod
    def validate_version(cls, value: str) -> str:
        if not _SEMVER_PATTERN.fullmatch(value):
            raise ValueError("version must use SemVer (major.minor.patch)")
        return value

    @field_validator("category")
    @classmethod
    def validate_category(cls, value: str) -> str:
        if not re.fullmatch(r"[a-z0-9][a-z0-9-]*", value):
            raise ValueError("category must be a lowercase slug")
        return value

    @field_validator("web_url", "health_endpoint")
    @classmethod
    def validate_http_url(cls, value: str | None) -> str | None:
        if value is None or value.startswith("/"):
            return value
        parsed = urlparse(value)
        if parsed.scheme not in {"http", "https"} or not parsed.hostname or parsed.username:
            raise ValueError("URL must be an absolute HTTP(S) URL or a relative path")
        return value

    @model_validator(mode="after")
    def validate_unique_fields(self) -> ToolManifest:
        env_names = [item.name for item in self.environment]
        if len(env_names) != len(set(env_names)):
            raise ValueError("environment variable names must be unique")
        port_names = [item.name for item in self.ports]
        if len(port_names) != len(set(port_names)):
            raise ValueError("port names must be unique")
        exposed_ports = [
            (item.host_port, item.protocol)
            for item in self.ports
            if isinstance(item.host_port, int) and item.exposure != "internal"
        ]
        if len(exposed_ports) != len(set(exposed_ports)):
            raise ValueError("declared host ports must be unique per protocol")
        if len(self.dependencies) != len(set(self.dependencies)):
            raise ValueError("dependencies must be unique")
        if self.web_url and not self.ports and not self.web_url.startswith("/"):
            if self.management.mode != "external":
                raise ValueError("managed web_url must reference a declared port or relative path")
        return self


@dataclass(frozen=True)
class DiscoveryIssue:
    manifest: str
    message: str

    def to_dict(self) -> dict[str, str]:
        return {"manifest": self.manifest, "message": self.message}


@dataclass(frozen=True)
class ToolManifestEntry:
    manifest: ToolManifest
    manifest_path: Path
    tool_directory: Path
    compose_file: Path | None
    project_directory: Path | None


class ToolRuntimeStatus(BaseModel):
    """Observed state supplied by a runtime adapter; no lifecycle actions here."""

    model_config = ConfigDict(extra="forbid")

    state: Literal[
        "NOT_INSTALLED", "INSTALLED", "STARTING", "RUNNING", "STOPPING", "STOPPED", "ERROR"
    ] = "NOT_INSTALLED"
    installation_state: Literal["NOT_INSTALLED", "INSTALLED"] | None = None
    runtime_state: Literal["STARTING", "RUNNING", "STOPPING", "STOPPED", "ERROR", "UNKNOWN"] = (
        "STOPPED"
    )
    web_url: str | None = None
    health_status: Literal["HEALTHY", "UNHEALTHY", "UNKNOWN", "NOT_CONFIGURED"] = "UNKNOWN"
    health_message: str | None = None
    error: str | None = None

    @model_validator(mode="after")
    def fill_installation_state(self) -> ToolRuntimeStatus:
        if self.installation_state is None:
            self.installation_state = (
                "NOT_INSTALLED" if self.state == "NOT_INSTALLED" else "INSTALLED"
            )
        return self


RuntimeStatusProvider = Callable[[ToolManifest], ToolRuntimeStatus | dict[str, Any] | None]


class ToolApplicationRegistry:
    """Discover and validate deploy manifests, then expose read-only status."""

    def __init__(
        self,
        deploy_dir: str | Path | None = None,
        *,
        status_provider: RuntimeStatusProvider | None = None,
    ) -> None:
        configured_root = deploy_dir or os.getenv("ETHAN_DEPLOY_DIR")
        self.deploy_dir = (
            Path(configured_root).expanduser().resolve()
            if configured_root
            else (Path(__file__).resolve().parents[2] / "deploy")
        )
        self.repository_root = self.deploy_dir.parent.resolve()
        self.status_provider = status_provider
        self._tools: dict[str, tuple[ToolManifest, Path]] = {}
        self._issues: list[DiscoveryIssue] = []
        self._lock = threading.RLock()
        self._last_refresh = 0.0
        self.refresh(force=True)

    @staticmethod
    def _format_validation_error(error: ValidationError) -> str:
        return "; ".join(
            f"{'.'.join(str(part) for part in item['loc'])}: {item['msg']}"
            for item in error.errors(include_url=False)
        )

    def _resolve_tool_path(self, raw_path: str, field: str, tool_directory: Path) -> Path:
        relative_path = Path(raw_path)
        if relative_path.is_absolute():
            raise ValueError(f"{field} must be relative to the Tool directory")
        candidate = (tool_directory / relative_path).resolve()
        try:
            candidate.relative_to(tool_directory.resolve())
        except ValueError as exc:
            raise ValueError(f"{field} escapes its Tool directory") from exc
        if not candidate.exists():
            raise ValueError(f"{field} does not exist: {raw_path}")
        return candidate

    def _load_manifest(self, manifest_path: Path) -> ToolManifestEntry:
        if manifest_path.stat().st_size > _MAX_MANIFEST_BYTES:
            raise ValueError(f"manifest exceeds {_MAX_MANIFEST_BYTES} bytes")
        raw = yaml.safe_load(manifest_path.read_text(encoding="utf-8"))
        if not isinstance(raw, dict):
            raise ValueError("manifest root must be a YAML mapping")
        manifest = ToolManifest.model_validate(raw)
        tool_directory = manifest_path.parent.resolve()
        compose_file: Path | None = None
        project_directory: Path | None = None
        if manifest.management.driver == "docker_compose":
            compose_file = self._resolve_tool_path(
                manifest.management.compose_file or "",
                "management.compose_file",
                tool_directory,
            )
            project_directory = self._resolve_tool_path(
                manifest.management.project_directory or "",
                "management.project_directory",
                tool_directory,
            )
            if not compose_file.is_file():
                raise ValueError("management.compose_file must reference a file")
            if not project_directory.is_dir():
                raise ValueError("management.project_directory must reference a directory")
            if not compose_file.is_relative_to(project_directory):
                raise ValueError("management.compose_file must be inside project_directory")
        return ToolManifestEntry(
            manifest=manifest,
            manifest_path=manifest_path.resolve(),
            tool_directory=tool_directory,
            compose_file=compose_file,
            project_directory=project_directory,
        )

    def refresh(self, *, force: bool = False) -> None:
        """Rescan immediate application directories; invalid files are isolated."""
        with self._lock:
            now = time.monotonic()
            if not force and now - self._last_refresh < 2.0:
                return
            self._last_refresh = now
            candidates: dict[str, list[ToolManifestEntry]] = {}
            issues: list[DiscoveryIssue] = []
            try:
                paths = sorted(self.deploy_dir.glob("*/ethan-tool.yml"))
            except OSError as exc:
                logger.exception("Could not scan tool manifests under %s", self.deploy_dir)
                self._tools = {}
                self._issues = [DiscoveryIssue(str(self.deploy_dir), f"scan failed: {exc}")]
                return

            for path in paths:
                relative = path.relative_to(self.repository_root).as_posix()
                try:
                    resolved_manifest = path.resolve()
                    resolved_manifest.relative_to(self.deploy_dir)
                    entry = self._load_manifest(path)
                except (OSError, UnicodeError, yaml.YAMLError, ValidationError, ValueError) as exc:
                    message = (
                        self._format_validation_error(exc)
                        if isinstance(exc, ValidationError)
                        else str(exc)
                    )
                    issues.append(DiscoveryIssue(relative, message))
                    logger.warning("Ignoring invalid Tool manifest %s: %s", relative, message)
                    continue
                candidates.setdefault(entry.manifest.id, []).append(entry)

            tools: dict[str, ToolManifestEntry] = {}
            for tool_id, entries in candidates.items():
                if len(entries) > 1:
                    names = ", ".join(
                        entry.manifest_path.relative_to(self.repository_root).as_posix()
                        for entry in entries
                    )
                    message = f"duplicate tool id '{tool_id}' declared by: {names}"
                    for entry in entries:
                        issues.append(
                            DiscoveryIssue(
                                entry.manifest_path.relative_to(self.repository_root).as_posix(),
                                message,
                            )
                        )
                    logger.warning("Ignoring duplicate Tool id %s: %s", tool_id, names)
                    continue
                tools[tool_id] = entries[0]

            self._tools = tools
            self._issues = issues

    def discovery_errors(self) -> list[dict[str, str]]:
        self.refresh()
        with self._lock:
            return [issue.to_dict() for issue in self._issues]

    def _serialize(self, tool_id: str, item: ToolManifestEntry) -> dict[str, Any]:
        manifest = item.manifest
        runtime_status: ToolRuntimeStatus | dict[str, Any] | None = None
        if self.status_provider is not None:
            try:
                runtime_status = self.status_provider(manifest)
            except Exception:
                logger.exception("Runtime status provider failed for tool %s", tool_id)
                runtime_status = {
                    "state": "ERROR",
                    "installation_state": "INSTALLED",
                    "runtime_state": "ERROR",
                    "health_status": "UNKNOWN",
                    "error": "Runtime status provider failed",
                }
        try:
            status = (
                runtime_status
                if isinstance(runtime_status, ToolRuntimeStatus)
                else ToolRuntimeStatus.model_validate(runtime_status or {})
            )
        except ValidationError:
            logger.exception("Invalid runtime status for tool %s", tool_id)
            status = ToolRuntimeStatus(
                state="ERROR",
                installation_state="INSTALLED",
                runtime_state="ERROR",
                error="Runtime status provider returned an invalid status",
            )
        data = manifest.model_dump(mode="json")
        data.update(status.model_dump(mode="json"))
        data["web_url"] = status.web_url or manifest.web_url
        data["manifest_path"] = item.manifest_path.relative_to(self.repository_root).as_posix()
        return data

    def get_manifest_entry(self, tool_id: str) -> ToolManifestEntry | None:
        """Return only a discovered and validated manifest and its confined paths."""
        self.refresh()
        with self._lock:
            return self._tools.get(tool_id)

    def list_tools(self) -> list[dict[str, Any]]:
        self.refresh()
        with self._lock:
            return [self._serialize(tool_id, item) for tool_id, item in sorted(self._tools.items())]

    def get_tool(self, tool_id: str) -> dict[str, Any] | None:
        self.refresh()
        with self._lock:
            item = self._tools.get(tool_id)
            return self._serialize(tool_id, item) if item else None

    def get_status(self, tool_id: str) -> dict[str, Any] | None:
        tool = self.get_tool(tool_id)
        if tool is None:
            return None
        return {
            "id": tool["id"],
            "state": tool["state"],
            "installation_state": tool["installation_state"],
            "runtime_state": tool["runtime_state"],
            "error": tool["error"],
        }

    def get_health(self, tool_id: str) -> dict[str, Any] | None:
        tool = self.get_tool(tool_id)
        if tool is None:
            return None
        return {
            "id": tool["id"],
            "status": tool["health_status"],
            "message": tool["health_message"],
            "endpoint": tool["health_endpoint"],
        }
