"""Generic, manifest-driven Docker Compose manager for ETHAN Tool applications.

Only the ETHAN API/Core invokes Docker. The browser supplies a Tool id and a
fixed operation; all Compose paths and arguments are derived from a validated
manifest discovered under ``deploy/``.
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import os
import re
import shutil
import socket
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Protocol
from urllib.parse import urljoin, urlparse

import httpx

from core.config.secrets import SecretManager
from core.deployment.tool_registry import (
    EnvironmentVariable,
    ToolApplicationRegistry,
    ToolManifest,
    ToolManifestEntry,
)

logger = logging.getLogger(__name__)

_ALLOWED_OPERATIONS = {"install", "start", "stop", "restart", "uninstall", "logs", "status"}
_PROJECT_ID = re.compile(r"^[a-z0-9][a-z0-9_-]{0,62}$")
_MAX_LOG_TAIL = 1000
_MAX_OUTPUT_BYTES = 2 * 1024 * 1024
_VOLUME_DELETE_CONFIRMATION = "DELETE_TOOL_DATA"


class ToolManagerError(Exception):
    """Base class for safe, user-facing Tool Manager errors."""


class ToolNotFoundError(ToolManagerError):
    pass


class ToolOperationNotAllowed(ToolManagerError):
    pass


class ToolConfigurationError(ToolManagerError):
    pass


class ToolDependencyError(ToolManagerError):
    pass


class ToolPortConflict(ToolManagerError):
    pass


class ToolDockerError(ToolManagerError):
    pass


class ToolTimeoutError(ToolDockerError):
    pass


class ToolConfirmationRequired(ToolManagerError):
    pass


@dataclass(frozen=True)
class ComposeResult:
    returncode: int
    stdout: str = ""
    stderr: str = ""
    timed_out: bool = False


class ComposeRunner(Protocol):
    async def __call__(
        self,
        argv: list[str],
        *,
        cwd: Path,
        env: dict[str, str],
        timeout: float,
    ) -> ComposeResult: ...


class DockerComposeRunner:
    """Run only server-built argv, without a shell, with bounded output/time."""

    def __init__(self, executable: str | None = None) -> None:
        configured = executable or os.getenv("ETHAN_DOCKER_COMPOSE_BIN")
        if configured:
            if Path(configured).name not in {"docker", "docker-compose"}:
                raise ValueError("ETHAN_DOCKER_COMPOSE_BIN must be docker or docker-compose")
            self.executable = shutil.which(configured) or configured
            self.use_compose_subcommand = Path(self.executable).name == "docker"
        else:
            docker = shutil.which("docker")
            compose = shutil.which("docker-compose")
            if compose:
                self.executable = compose
                self.use_compose_subcommand = False
            elif docker:
                self.executable = docker
                self.use_compose_subcommand = True
            else:
                self.executable = "docker"
                self.use_compose_subcommand = True

    async def __call__(
        self,
        argv: list[str],
        *,
        cwd: Path,
        env: dict[str, str],
        timeout: float,
    ) -> ComposeResult:
        command = [self.executable, *(["compose"] if self.use_compose_subcommand else []), *argv]
        try:
            process = await asyncio.create_subprocess_exec(
                *command,
                cwd=str(cwd),
                env=env,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
        except FileNotFoundError as exc:
            raise ToolDockerError("Docker Compose n’est pas installé sur le serveur") from exc
        except OSError as exc:
            raise ToolDockerError("Impossible d’accéder au client ou daemon Docker") from exc
        try:
            stdout, stderr = await asyncio.wait_for(process.communicate(), timeout=timeout)
        except TimeoutError:
            process.kill()
            await process.communicate()
            return ComposeResult(-1, timed_out=True, stderr=f"timeout après {timeout:.0f}s")
        return ComposeResult(
            returncode=process.returncode or 0,
            stdout=stdout[-_MAX_OUTPUT_BYTES:].decode("utf-8", errors="replace"),
            stderr=stderr[-_MAX_OUTPUT_BYTES:].decode("utf-8", errors="replace"),
        )


class ToolManager:
    """Lifecycle manager for all managed Tools, driven by validated manifests."""

    def __init__(
        self,
        registry: ToolApplicationRegistry,
        *,
        runner: ComposeRunner | None = None,
        secret_manager: SecretManager | None = None,
        operation_timeout: float = 600.0,
        health_timeout: float = 45.0,
    ) -> None:
        self.registry = registry
        self.runner = runner or DockerComposeRunner()
        self.secret_manager = secret_manager or SecretManager()
        self.operation_timeout = operation_timeout
        self.health_timeout = health_timeout
        self._locks: dict[str, asyncio.Lock] = {}

    def _entry(self, tool_id: str) -> ToolManifestEntry:
        entry = self.registry.get_manifest_entry(tool_id)
        if entry is None:
            raise ToolNotFoundError(f"Tool '{tool_id}' introuvable dans le registre")
        return entry

    def _managed(self, entry: ToolManifestEntry) -> tuple[Path, Path]:
        manifest = entry.manifest
        if manifest.management.mode != "managed" or manifest.management.driver != "docker_compose":
            raise ToolOperationNotAllowed(
                "Ce Tool est externe et n’est pas géré par Docker Compose"
            )
        if entry.compose_file is None or entry.project_directory is None:
            raise ToolConfigurationError("Chemins Docker Compose absents du manifest validé")
        return entry.compose_file, entry.project_directory

    def _ensure_operation(self, manifest: ToolManifest, operation: str) -> None:
        if operation not in _ALLOWED_OPERATIONS:
            raise ToolOperationNotAllowed("Opération inconnue")
        if operation != "status" and operation not in manifest.operations:
            raise ToolOperationNotAllowed(
                f"L’opération '{operation}' n’est pas autorisée par le manifest"
            )

    def _compose_argv(self, entry: ToolManifestEntry, *args: str) -> list[str]:
        compose_file, project_directory = self._managed(entry)
        tool_id = entry.manifest.id
        suffix = hashlib.sha256(tool_id.encode("utf-8")).hexdigest()[:8]
        configured_name = entry.manifest.management.project_name or tool_id
        project_name = f"ethan-tool-{configured_name[:42]}-{suffix}"
        if not _PROJECT_ID.fullmatch(project_name):
            raise ToolConfigurationError("Identifiant de projet Compose invalide")
        argv = [
            "--project-directory",
            str(project_directory),
            "--file",
            str(compose_file),
            "--project-name",
            project_name,
        ]
        for profile in entry.manifest.management.profiles:
            argv.extend(("--profile", profile))
        argv.extend(args)
        return argv

    @staticmethod
    def _string_value(variable: EnvironmentVariable, value: Any) -> str:
        if variable.type == "integer":
            try:
                return str(int(value))
            except (ValueError, TypeError) as exc:
                raise ToolConfigurationError(
                    f"La variable {variable.name} doit être un entier"
                ) from exc
        if variable.type == "boolean":
            normalized = str(value).strip().lower()
            if normalized not in {"true", "false", "1", "0", "yes", "no"}:
                raise ToolConfigurationError(f"La variable {variable.name} doit être booléenne")
            return "true" if normalized in {"true", "1", "yes"} else "false"
        result = str(value)
        if variable.type == "url":
            parsed = urlparse(result)
            if parsed.scheme not in {"http", "https"} or not parsed.hostname:
                raise ToolConfigurationError(
                    f"La variable {variable.name} doit être une URL HTTP(S)"
                )
        return result

    async def _compose_environment(
        self, manifest: ToolManifest, *, require_required: bool
    ) -> tuple[dict[str, str], list[str]]:
        # Do not leak unrelated API process secrets to Compose interpolation.
        env = {
            "PATH": os.getenv("PATH", "/usr/local/bin:/usr/bin:/bin"),
            "HOME": os.getenv("HOME", "/tmp"),
            "COMPOSE_ANSI": "never",
            "COMPOSE_DISABLE_ENV_FILE": "1",
        }
        for key in ("DOCKER_HOST", "DOCKER_CONFIG", "DOCKER_CONTEXT", "SSL_CERT_FILE"):
            value = os.getenv(key)
            if value:
                env[key] = value
        secrets: list[str] = []
        missing: list[str] = []
        for variable in manifest.environment:
            value: Any = os.getenv(variable.name)
            if value is None and variable.secret_ref:
                value = await asyncio.to_thread(
                    self.secret_manager.get_or_none, variable.secret_ref
                )
            # Empty values are how optional Tool secrets are passed through the
            # ETHAN API container when an operator has not configured them.
            # Never treat an empty secret as satisfying a required credential.
            if variable.secret and value == "":
                value = None
            if value is None:
                value = variable.default
            if value is None:
                if variable.required:
                    if require_required:
                        missing.append(variable.name)
                    else:
                        # Compose evaluates ${VAR:?} even for read-only commands
                        # such as `ps` and `logs`. A local sentinel lets those
                        # commands inspect/stop an unconfigured installation;
                        # install/start still require the real manifest values.
                        sentinel = "__ETHAN_REQUIRED_VALUE_UNCONFIGURED__"
                        env[variable.name] = sentinel
                        if variable.secret:
                            secrets.append(sentinel)
                continue
            normalized = self._string_value(variable, value)
            env[variable.name] = normalized
            if variable.secret:
                secrets.append(normalized)
        if missing:
            raise ToolConfigurationError(
                "Variables obligatoires absentes : " + ", ".join(sorted(missing))
            )
        return env, secrets

    @staticmethod
    def _redact(text: str, secrets: list[str]) -> str:
        for secret in sorted((secret for secret in secrets if secret), key=len, reverse=True):
            text = text.replace(secret, "[REDACTED]")
        return text

    async def _run(
        self,
        entry: ToolManifestEntry,
        *args: str,
        timeout: float | None = None,
        require_required: bool = False,
    ) -> ComposeResult:
        _, project_directory = self._managed(entry)
        env, secrets = await self._compose_environment(
            entry.manifest, require_required=require_required
        )
        effective_timeout = timeout or self.operation_timeout
        try:
            # Enforce the deadline at the manager boundary too. Injected runners
            # (and alternate adapters) must not be able to hang an API request.
            result = await asyncio.wait_for(
                self.runner(
                    self._compose_argv(entry, *args),
                    cwd=project_directory,
                    env=env,
                    timeout=effective_timeout,
                ),
                timeout=effective_timeout,
            )
        except TimeoutError as exc:
            raise ToolTimeoutError(
                f"Docker Compose a dépassé le délai de {effective_timeout:.0f}s"
            ) from exc
        result = ComposeResult(
            result.returncode,
            self._redact(result.stdout, secrets),
            self._redact(result.stderr, secrets),
            result.timed_out,
        )
        if result.timed_out:
            raise ToolTimeoutError(
                f"Docker Compose a dépassé le délai de {timeout or self.operation_timeout:.0f}s"
            )
        if result.returncode != 0:
            detail = (result.stderr or result.stdout).strip()[-1200:]
            raise ToolDockerError(detail or "Docker Compose a échoué")
        return result

    def _check_ports(self, manifest: ToolManifest) -> None:
        seen: set[tuple[str, int, str]] = set()
        for port in manifest.ports:
            if port.exposure == "internal" or not isinstance(port.host_port, int):
                continue
            address = "127.0.0.1" if port.exposure == "loopback" else "0.0.0.0"
            key = (address, port.host_port, port.protocol)
            if key in seen:
                raise ToolPortConflict(f"Port hôte déclaré plusieurs fois : {port.host_port}")
            seen.add(key)
            sock_type = socket.SOCK_DGRAM if port.protocol == "udp" else socket.SOCK_STREAM
            try:
                with socket.socket(socket.AF_INET, sock_type) as probe:
                    probe.bind((address, port.host_port))
            except OSError as exc:
                raise ToolPortConflict(
                    f"Le port hôte {port.host_port}/{port.protocol} est déjà utilisé"
                ) from exc

    async def _check_dependencies(self, entry: ToolManifestEntry, *, require_running: bool) -> None:
        for dependency_id in entry.manifest.dependencies:
            dependency = self.registry.get_manifest_entry(dependency_id)
            if dependency is None:
                raise ToolDependencyError(f"Dépendance déclarée introuvable : {dependency_id}")
            dependency_status = await self._status_entry(dependency)
            if dependency_status["installation_state"] != "INSTALLED":
                raise ToolDependencyError(f"Dépendance non installée : {dependency_id}")
            if require_running and dependency_status["runtime_state"] != "RUNNING":
                raise ToolDependencyError(f"Dépendance non démarrée : {dependency_id}")

    @staticmethod
    def _parse_compose_ps(output: str) -> list[dict[str, Any]]:
        text = output.strip()
        if not text:
            return []
        try:
            value = json.loads(text)
            if isinstance(value, list):
                return [item for item in value if isinstance(item, dict)]
            if isinstance(value, dict):
                return [value]
        except json.JSONDecodeError:
            pass
        rows: list[dict[str, Any]] = []
        for line in text.splitlines():
            try:
                item = json.loads(line)
            except json.JSONDecodeError as exc:
                raise ToolDockerError("Réponse JSON invalide de docker compose ps") from exc
            if isinstance(item, dict):
                rows.append(item)
        return rows

    async def _health(self, manifest: ToolManifest) -> dict[str, Any]:
        endpoint = manifest.health_endpoint
        if not endpoint:
            return {"status": "NOT_CONFIGURED", "message": None, "endpoint": None}
        if endpoint.startswith("/"):
            base_url = manifest.web_url
            if not base_url or not base_url.startswith(("http://", "https://")):
                return {
                    "status": "UNKNOWN",
                    "message": "Health-check relatif sans URL Web absolue",
                    "endpoint": endpoint,
                }
            endpoint = urljoin(base_url.rstrip("/") + "/", endpoint.lstrip("/"))
        try:
            async with httpx.AsyncClient(timeout=3.0, follow_redirects=True) as client:
                response = await client.get(endpoint)
            healthy = 200 <= response.status_code < 400
            return {
                "status": "HEALTHY" if healthy else "UNHEALTHY",
                "message": f"HTTP {response.status_code}",
                "endpoint": endpoint,
            }
        except (httpx.HTTPError, TimeoutError) as exc:
            return {
                "status": "UNHEALTHY",
                "message": f"Injoignable ({type(exc).__name__})",
                "endpoint": endpoint,
            }

    async def _status_entry(self, entry: ToolManifestEntry) -> dict[str, Any]:
        manifest = entry.manifest
        if manifest.management.mode == "external":
            health = await self._health(manifest)
            runtime_state = "RUNNING" if health["status"] == "HEALTHY" else "UNKNOWN"
            state = "RUNNING" if runtime_state == "RUNNING" else "INSTALLED"
            if health["status"] == "UNHEALTHY":
                runtime_state = "ERROR"
                state = "ERROR"
            return {
                "state": state,
                "installation_state": "INSTALLED",
                "runtime_state": runtime_state,
                "health_status": health["status"],
                "health_message": health["message"],
                "health_endpoint": health["endpoint"],
                "web_url": manifest.web_url,
                "error": health["message"] if state == "ERROR" else None,
            }

        try:
            result = await self._run(entry, "ps", "--all", "--format", "json", timeout=15)
        except ToolManagerError as exc:
            return {
                "state": "ERROR",
                "installation_state": "NOT_INSTALLED",
                "runtime_state": "ERROR",
                "health_status": "UNKNOWN",
                "health_message": None,
                "health_endpoint": manifest.health_endpoint,
                "web_url": manifest.web_url,
                "error": str(exc),
            }
        rows = self._parse_compose_ps(result.stdout)
        if not rows:
            return {
                "state": "NOT_INSTALLED",
                "installation_state": "NOT_INSTALLED",
                "runtime_state": "STOPPED",
                "health_status": "UNKNOWN" if manifest.health_endpoint else "NOT_CONFIGURED",
                "health_message": None,
                "health_endpoint": manifest.health_endpoint,
                "web_url": manifest.web_url,
                "error": None,
            }

        states = [str(row.get("State", row.get("state", "unknown"))).lower() for row in rows]
        running = any(state in {"running", "up"} for state in states)
        failed = False
        for row, state in zip(rows, states, strict=True):
            if state not in {"running", "up", "exited", "stopped", "created"}:
                failed = True
                break
            if state == "exited":
                try:
                    failed = int(row.get("ExitCode", row.get("exitCode", 0)) or 0) != 0
                except (TypeError, ValueError):
                    failed = True
                if failed:
                    break
        restarting = any(state == "restarting" for state in states)
        if failed:
            runtime_state = "ERROR"
        elif restarting:
            runtime_state = "STARTING"
        elif running:
            runtime_state = "RUNNING"
        else:
            runtime_state = "STOPPED"
        if manifest.health_endpoint:
            health = await self._health(manifest)
        else:
            compose_health = [str(row.get("Health", row.get("health", ""))).lower() for row in rows]
            configured_health = [value for value in compose_health if value]
            if configured_health and all(value == "healthy" for value in configured_health):
                health = {
                    "status": "HEALTHY",
                    "message": "Docker healthcheck healthy",
                    "endpoint": None,
                }
            elif any(value == "unhealthy" for value in configured_health):
                health = {
                    "status": "UNHEALTHY",
                    "message": "Docker healthcheck unhealthy",
                    "endpoint": None,
                }
            elif configured_health:
                health = {
                    "status": "UNKNOWN",
                    "message": "Docker healthcheck is starting",
                    "endpoint": None,
                }
            else:
                health = {"status": "NOT_CONFIGURED", "message": None, "endpoint": None}
        state = runtime_state
        error = None
        if runtime_state == "RUNNING" and health["status"] == "UNHEALTHY":
            state = "ERROR"
            error = health["message"]
        elif runtime_state == "STOPPED":
            state = "STOPPED"
        elif runtime_state == "ERROR":
            state = "ERROR"
            error = "Un ou plusieurs services Compose sont en erreur"
        return {
            "state": state,
            "installation_state": "INSTALLED",
            "runtime_state": runtime_state,
            "health_status": health["status"],
            "health_message": health["message"],
            "health_endpoint": health["endpoint"],
            "web_url": manifest.web_url,
            "error": error,
        }

    async def status(self, tool_id: str) -> dict[str, Any]:
        entry = self._entry(tool_id)
        status = await self._status_entry(entry)
        return {"id": tool_id, **status}

    async def health(self, tool_id: str) -> dict[str, Any]:
        entry = self._entry(tool_id)
        status = await self._status_entry(entry)
        return {
            "id": tool_id,
            "status": status["health_status"],
            "message": status["health_message"],
            "endpoint": status["health_endpoint"],
        }

    async def get_tool(self, tool_id: str) -> dict[str, Any]:
        entry = self._entry(tool_id)
        serialized = entry.manifest.model_dump(mode="json")
        status = await self._status_entry(entry)
        serialized.update(status)
        serialized["manifest_path"] = entry.manifest_path.relative_to(
            self.registry.repository_root
        ).as_posix()
        return serialized

    async def list_tools(self) -> list[dict[str, Any]]:
        entries = self.registry.list_tools()
        return list(await asyncio.gather(*(self.get_tool(value["id"]) for value in entries)))

    async def _wait_for_health(self, entry: ToolManifestEntry) -> dict[str, Any]:
        deadline = time.monotonic() + self.health_timeout
        status = await self._status_entry(entry)
        last = {
            "status": status["health_status"],
            "message": status["health_message"],
            "endpoint": status["health_endpoint"],
        }
        while last["status"] != "HEALTHY" and time.monotonic() < deadline:
            if last["status"] == "NOT_CONFIGURED":
                break
            await asyncio.sleep(min(1.0, max(0.0, deadline - time.monotonic())))
            status = await self._status_entry(entry)
            last = {
                "status": status["health_status"],
                "message": status["health_message"],
                "endpoint": status["health_endpoint"],
            }
        return last

    async def _operation(
        self,
        tool_id: str,
        operation: str,
        *,
        actor: str | None = None,
        delete_volumes: bool = False,
        confirmation: str | None = None,
    ) -> dict[str, Any]:
        entry = self._entry(tool_id)
        self._ensure_operation(entry.manifest, operation)
        lock = self._locks.setdefault(tool_id, asyncio.Lock())
        async with lock:
            logger.info(
                "Tool operation started tool_id=%s operation=%s actor=%s", tool_id, operation, actor
            )
            try:
                if operation == "install":
                    await self._check_dependencies(entry, require_running=False)
                    await self._compose_environment(entry.manifest, require_required=True)
                    self._check_ports(entry.manifest)
                    await self._run(entry, "create", "--build", require_required=True)
                elif operation == "start":
                    current = await self._status_entry(entry)
                    if current["installation_state"] != "INSTALLED":
                        raise ToolOperationNotAllowed("Installez le Tool avant de le démarrer")
                    await self._check_dependencies(entry, require_running=True)
                    if current["runtime_state"] != "RUNNING":
                        self._check_ports(entry.manifest)
                    await self._run(entry, "up", "--detach", "--no-build", require_required=True)
                    health = await self._wait_for_health(entry)
                    if health["status"] in {"UNHEALTHY", "UNKNOWN"}:
                        raise ToolTimeoutError(
                            f"Health-check non confirmé : {health['message'] or health['status']}"
                        )
                elif operation == "stop":
                    current = await self._status_entry(entry)
                    if current["installation_state"] != "INSTALLED":
                        raise ToolOperationNotAllowed("Le Tool n’est pas installé")
                    await self._run(entry, "stop")
                elif operation == "restart":
                    current = await self._status_entry(entry)
                    if current["installation_state"] != "INSTALLED":
                        raise ToolOperationNotAllowed("Le Tool n’est pas installé")
                    await self._check_dependencies(entry, require_running=True)
                    await self._compose_environment(entry.manifest, require_required=True)
                    if current["runtime_state"] != "RUNNING":
                        self._check_ports(entry.manifest)
                    await self._run(entry, "restart")
                    health = await self._wait_for_health(entry)
                    if health["status"] in {"UNHEALTHY", "UNKNOWN"}:
                        raise ToolTimeoutError(
                            f"Health-check non confirmé : {health['message'] or health['status']}"
                        )
                elif operation == "uninstall":
                    args = ["down", "--remove-orphans"]
                    if delete_volumes:
                        if confirmation != _VOLUME_DELETE_CONFIRMATION:
                            raise ToolConfirmationRequired(
                                "Pour supprimer les volumes, confirmation exacte requise : "
                                "DELETE_TOOL_DATA"
                            )
                        args.append("--volumes")
                    await self._run(entry, *args)
                else:
                    raise ToolOperationNotAllowed(f"Opération non gérée : {operation}")
                status = await self._status_entry(entry)
                logger.info(
                    "Tool operation succeeded tool_id=%s operation=%s actor=%s state=%s",
                    tool_id,
                    operation,
                    actor,
                    status["state"],
                )
                return {"id": tool_id, "operation": operation, **status}
            except Exception as exc:
                logger.error(
                    "Tool operation failed tool_id=%s operation=%s actor=%s error_type=%s",
                    tool_id,
                    operation,
                    actor,
                    type(exc).__name__,
                )
                raise

    async def install(self, tool_id: str, *, actor: str | None = None) -> dict[str, Any]:
        return await self._operation(tool_id, "install", actor=actor)

    async def start(self, tool_id: str, *, actor: str | None = None) -> dict[str, Any]:
        return await self._operation(tool_id, "start", actor=actor)

    async def stop(self, tool_id: str, *, actor: str | None = None) -> dict[str, Any]:
        return await self._operation(tool_id, "stop", actor=actor)

    async def restart(self, tool_id: str, *, actor: str | None = None) -> dict[str, Any]:
        return await self._operation(tool_id, "restart", actor=actor)

    async def uninstall(
        self,
        tool_id: str,
        *,
        actor: str | None = None,
        delete_volumes: bool = False,
        confirmation: str | None = None,
    ) -> dict[str, Any]:
        return await self._operation(
            tool_id,
            "uninstall",
            actor=actor,
            delete_volumes=delete_volumes,
            confirmation=confirmation,
        )

    async def logs(
        self, tool_id: str, *, tail: int = 200, actor: str | None = None
    ) -> dict[str, Any]:
        entry = self._entry(tool_id)
        self._ensure_operation(entry.manifest, "logs")
        if not 1 <= tail <= _MAX_LOG_TAIL:
            raise ToolConfigurationError(f"tail doit être compris entre 1 et {_MAX_LOG_TAIL}")
        logger.info("Tool logs requested tool_id=%s actor=%s tail=%s", tool_id, actor, tail)
        result = await self._run(entry, "logs", "--no-color", "--tail", str(tail), timeout=30)
        _, secrets = await self._compose_environment(entry.manifest, require_required=False)
        return {
            "id": tool_id,
            "available": True,
            "logs": self._redact(result.stdout + result.stderr, secrets),
        }
